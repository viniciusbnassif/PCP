package com.liderMinas.PCP

import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Bundle
import android.view.Menu
import android.text.Editable
import android.view.View
import android.widget.*
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.util.*


class ApontamentoPerdas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apontamento_perdas)

        // calling the action bar
        val toolbar = findViewById<Toolbar?>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.apply {
            // show back button on toolbar
            // on back button press, it will navigate to parent activity
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowCustomEnabled(true)
        }



        intent = getIntent();

        var name = intent.getStringExtra("messageIntent")


        val dateFormatter = SimpleDateFormat("dd/MM/yyyy")
        val dty = dateFormatter.format(Date())

        //findViewById<TextView>(R.id.finalDate).apply { text = dty }

        val dateFormatter0 = SimpleDateFormat("kk:mm")
        val time = dateFormatter0.format(Date())

        //findViewById<TextView>(R.id.finalTime).apply { text = time }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.apontamento_perdas, menu)
        return true
    }

    override fun onNavigateUp(): Boolean {
        return super.onNavigateUp()
    }
}